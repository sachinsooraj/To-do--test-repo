To -Do List application

Notes
1. Dockerfile is stored in the Backend and Frontend folder.

2. For easy useage I have uploaded the docker images to dockerhub USER: sachinondocker
 backend image: sachinondocker/to-do-backend
 Frontend image: sachinondocker/to-do-frontend

3. All the Kubernetes Deployments and services are stored in the Kubernetes folder
This application need MongoDB so we have created a manifest for it.
4. main.tf is the terraform file

Geting Started

1. CD to /Kubernetes
2. kubectl apply -f frontend-deployment.yaml (frontend deployemnt file)
3. kubectl apply -f frontend-service.yaml (service file you can access it in port 3000)
4. kubectl apply -f mongo-deployment.yaml (MongoDB file for the DB storage)
5. kubectl apply -f mongo-pvc.yaml (MongoDB Presistent volume file)
6. kubectl apply -f backend-deployment.yaml (backend deployment file)
7. kubectl apply -f HPA-backend.yaml (Horizontal Pod Scaling file. I have added it seperatly)

After Applying all the kubectl command the application is ready to run. Port:3000


Using Terraform
1. Main.tf file is configured with all the kubernetes file. Which is ready to config to AWS EKS
before apply the command please configure the AWS credentials in the terraform.
Use
    1. terraform init
    2. terraform apply


For Monitoring using Grafana - Prometheus

1. sudo apt-get install helm
2. helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
3. helm repo update
4. helm install prometheus prometheus-community/prometheus
5. kubectl expose service prometheus-server --type=NodePort --target-port=9090 --name=prometheus-server-ext
6. helm repo add grafana https://grafana.github.io/helm-charts 
7. helm repo update
8. helm install grafana grafana/grafana
9. kubectl expose service grafana --type=NodePort --target-port=3000 --name=grafana-ext


Login to Grafana and Configure the dashboard with to-do app and Monitor.
